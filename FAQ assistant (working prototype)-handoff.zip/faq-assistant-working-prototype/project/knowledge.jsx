// ============================================================
// Mutual Fund FAQ Assistant — grounded knowledge base
// Scope (per BRD): one AMC (SBI Mutual Fund), 3–5 schemes.
// All values are illustrative prototype data with citations.
// ============================================================

const LAST_UPDATED = "29 May 2026";

const SOURCES = {
  sid: {
    label: "SBI Mutual Fund – Scheme Information Document (SID)",
    url: "https://www.sbimf.com",
    org: "SBI Mutual Fund",
  },
  factsheet: {
    label: "SBI Mutual Fund – Monthly Factsheet",
    url: "https://www.sbimf.com",
    org: "SBI Mutual Fund",
  },
  kim: {
    label: "SBI Mutual Fund – Key Information Memorandum (KIM)",
    url: "https://www.sbimf.com",
    org: "SBI Mutual Fund",
  },
  amfi: {
    label: "AMFI – Investor Awareness & Riskometer",
    url: "https://www.amfiindia.com",
    org: "AMFI",
  },
  sebi: {
    label: "SEBI – Investor Education: Introduction to Mutual Funds",
    url: "https://investor.sebi.gov.in",
    org: "SEBI",
  },
};

// Scheme corpus -------------------------------------------------
const SCHEMES = {
  "sbi small cap": {
    name: "SBI Small Cap Fund",
    category: "Small Cap • Equity • Open-ended",
    aliases: ["sbi small cap", "small cap"],
    facts: {
      "expense ratio": {
        label: "Expense Ratio",
        value: "Regular plan: 1.62% p.a.  ·  Direct plan: 0.67% p.a.",
        src: "factsheet",
      },
      "exit load": {
        label: "Exit Load",
        value: "1% if redeemed within 1 year from the date of allotment. Nil thereafter.",
        src: "sid",
      },
      "benchmark": {
        label: "Benchmark",
        value: "BSE 250 SmallCap Total Return Index (TRI).",
        src: "factsheet",
      },
      "riskometer": {
        label: "Riskometer",
        value: "Very High risk. Suitable for investors seeking long-term capital appreciation.",
        src: "amfi",
      },
      "lock-in period": {
        label: "Lock-in Period",
        value: "No lock-in. The scheme is open-ended; units can be redeemed on any business day.",
        src: "sid",
      },
      "minimum sip": {
        label: "Minimum SIP",
        value: "₹500 per instalment (minimum 12 instalments). Minimum lumpsum: ₹5,000.",
        src: "kim",
      },
    },
  },
  "sbi bluechip": {
    name: "SBI Bluechip Fund",
    category: "Large Cap • Equity • Open-ended",
    aliases: ["sbi bluechip", "sbi blue chip", "bluechip", "blue chip"],
    facts: {
      "expense ratio": {
        label: "Expense Ratio",
        value: "Regular plan: 1.55% p.a.  ·  Direct plan: 0.80% p.a.",
        src: "factsheet",
      },
      "exit load": {
        label: "Exit Load",
        value: "1% if redeemed within 1 year from the date of allotment. Nil thereafter.",
        src: "sid",
      },
      "benchmark": {
        label: "Benchmark",
        value: "BSE 100 Total Return Index (TRI).",
        src: "factsheet",
      },
      "riskometer": {
        label: "Riskometer",
        value: "Very High risk. Invests predominantly in large-cap equity.",
        src: "amfi",
      },
      "lock-in period": {
        label: "Lock-in Period",
        value: "No lock-in. Open-ended scheme; redeemable on any business day.",
        src: "sid",
      },
      "minimum sip": {
        label: "Minimum SIP",
        value: "₹500 per instalment. Minimum lumpsum: ₹5,000.",
        src: "kim",
      },
    },
  },
  "sbi long term equity": {
    name: "SBI Long Term Equity Fund",
    category: "ELSS • Tax Saver • Open-ended",
    aliases: [
      "sbi long term equity",
      "sbi long term",
      "elss",
      "tax saver",
      "tax saving",
      "80c",
      "long term equity",
    ],
    facts: {
      "expense ratio": {
        label: "Expense Ratio",
        value: "Regular plan: 1.58% p.a.  ·  Direct plan: 0.94% p.a.",
        src: "factsheet",
      },
      "exit load": {
        label: "Exit Load",
        value: "Nil. (Units are subject to a statutory 3-year lock-in.)",
        src: "sid",
      },
      "benchmark": {
        label: "Benchmark",
        value: "BSE 500 Total Return Index (TRI).",
        src: "factsheet",
      },
      "riskometer": {
        label: "Riskometer",
        value: "Very High risk. Diversified equity ELSS scheme.",
        src: "amfi",
      },
      "lock-in period": {
        label: "Lock-in Period",
        value: "3 years from the date of allotment (statutory lock-in for ELSS funds under Section 80C).",
        src: "sid",
      },
      "minimum sip": {
        label: "Minimum SIP",
        value: "₹500 per instalment. Minimum lumpsum: ₹500 (in multiples of ₹500).",
        src: "kim",
      },
    },
  },
  "sbi magnum midcap": {
    name: "SBI Magnum Midcap Fund",
    category: "Mid Cap • Equity • Open-ended",
    aliases: ["sbi magnum midcap", "magnum midcap", "midcap", "mid cap", "sbi midcap"],
    facts: {
      "expense ratio": {
        label: "Expense Ratio",
        value: "Regular plan: 1.69% p.a.  ·  Direct plan: 0.88% p.a.",
        src: "factsheet",
      },
      "exit load": {
        label: "Exit Load",
        value: "1% if redeemed within 1 year from the date of allotment. Nil thereafter.",
        src: "sid",
      },
      "benchmark": {
        label: "Benchmark",
        value: "BSE 150 MidCap Total Return Index (TRI).",
        src: "factsheet",
      },
      "riskometer": {
        label: "Riskometer",
        value: "Very High risk. Invests predominantly in mid-cap equity.",
        src: "amfi",
      },
      "lock-in period": {
        label: "Lock-in Period",
        value: "No lock-in. Open-ended scheme; redeemable on any business day.",
        src: "sid",
      },
      "minimum sip": {
        label: "Minimum SIP",
        value: "₹500 per instalment. Minimum lumpsum: ₹5,000.",
        src: "kim",
      },
    },
  },
};

// Generic / process FAQs (not scheme-specific) -----------------
const GENERIC = [
  {
    keys: ["capital gains statement", "capital gain statement", "capital gains"],
    label: "Downloading your Capital Gains Statement",
    value:
      "Log in to the SBI Mutual Fund website or app → go to 'Statements' → select 'Capital Gains Statement' → choose the financial year → download the PDF. You can also request it via CAMS/KFintech using your registered email.",
    src: "factsheet",
  },
  {
    keys: ["account statement", "download statement", "statement download", "transaction statement"],
    label: "Downloading your Account Statement",
    value:
      "Log in to the SBI Mutual Fund website or app → 'Statements' → 'Account Statement' → select date range → download. A consolidated statement (CAS) is also emailed monthly by the RTA.",
    src: "factsheet",
  },
  {
    keys: ["what is expense ratio", "expense ratio mean", "define expense ratio"],
    label: "What is an Expense Ratio?",
    value:
      "The expense ratio is the annual fee an AMC charges to manage a scheme, expressed as a percentage of assets. It is deducted from the fund's NAV. Direct plans have lower expense ratios than regular plans.",
    src: "sebi",
  },
  {
    keys: ["what is exit load", "exit load mean", "define exit load"],
    label: "What is an Exit Load?",
    value:
      "An exit load is a fee charged when you redeem units before a specified period. It is meant to discourage early withdrawals and is expressed as a percentage of the redemption amount.",
    src: "sebi",
  },
  {
    keys: ["what is riskometer", "riskometer mean", "define riskometer"],
    label: "What is a Riskometer?",
    value:
      "The Riskometer is a SEBI-mandated visual indicator showing a scheme's risk level on a 6-point scale: Low, Low to Moderate, Moderate, Moderately High, High and Very High. It is reviewed monthly.",
    src: "amfi",
  },
];

// Advice / opinion detection -----------------------------------
const ADVICE_PATTERNS = [
  /\bshould i\b/i,
  /\bshould we\b/i,
  /\bis it (a )?(good|bad|wise|smart|safe)\b/i,
  /\b(which|what) (is |is the |fund )?(is )?best\b/i,
  /\bbetter than\b/i,
  /\bworth (it|buying|investing)\b/i,
  /\b(recommend|suggest|advice|advise)\b/i,
  /\bbuy or sell\b/i,
  /\bshould i (buy|sell|invest|redeem|switch)\b/i,
  /\bwill (it|this|the fund) (go up|rise|fall|grow|give returns|double)\b/i,
  /\bgood time to (buy|invest|sell)\b/i,
  /\bhow much (will|can) i (earn|make|gain)\b/i,
  /\bfuture returns?\b/i,
  /\bguaranteed returns?\b/i,
  /\bmultibagger\b/i,
];

function isAdviceQuery(q) {
  return ADVICE_PATTERNS.some((re) => re.test(q));
}

function findScheme(q) {
  const lc = q.toLowerCase();
  let best = null;
  let bestLen = 0;
  for (const key in SCHEMES) {
    for (const alias of SCHEMES[key].aliases) {
      if (lc.includes(alias) && alias.length > bestLen) {
        best = SCHEMES[key];
        bestLen = alias.length;
      }
    }
  }
  return best;
}

const TOPIC_MATCHERS = [
  { topic: "expense ratio", re: /\bexpense ratio\b|\bter\b|\bcharges?\b|\bfee\b/i },
  { topic: "exit load", re: /\bexit load\b|\bredemption (fee|charge)\b/i },
  { topic: "benchmark", re: /\bbenchmark\b|\bindex\b|\bcompared (against|to)\b/i },
  { topic: "riskometer", re: /\briskometer\b|\brisk level\b|\bhow risky\b|\brisk\b/i },
  { topic: "lock-in period", re: /\block[- ]?in\b|\blockin\b|\bhold(ing)? period\b/i },
  { topic: "minimum sip", re: /\bminimum (sip|investment|amount)\b|\bmin sip\b|\bsip amount\b|\blumpsum\b/i },
];

function findTopic(q) {
  for (const m of TOPIC_MATCHERS) {
    if (m.re.test(q)) return m.topic;
  }
  return null;
}

function findGeneric(q) {
  const lc = q.toLowerCase();
  for (const g of GENERIC) {
    if (g.keys.some((k) => lc.includes(k))) return g;
  }
  return null;
}

// Returns a structured answer object, or null if it can't answer locally.
// Shape: { type: 'answer'|'refusal', heading, body, source, schemeName }
function answerLocally(q) {
  if (isAdviceQuery(q)) {
    return {
      type: "refusal",
      heading: null,
      body:
        "I can only provide factual information about mutual funds from official AMC, SEBI and AMFI sources. I can't offer investment advice, recommendations or predictions. For investment decisions, please refer to educational resources from SEBI or consult a SEBI-registered advisor.",
      source: SOURCES.sebi,
    };
  }

  const generic = findGeneric(q);
  if (generic) {
    return {
      type: "answer",
      heading: generic.label,
      body: generic.value,
      source: SOURCES[generic.src],
    };
  }

  const scheme = findScheme(q);
  const topic = findTopic(q);

  if (scheme && topic) {
    const fact = scheme.facts[topic];
    return {
      type: "answer",
      heading: fact.label + " — " + scheme.name,
      body: fact.value,
      source: SOURCES[fact.src],
      schemeName: scheme.name,
    };
  }

  if (scheme && !topic) {
    // Scheme known but no specific topic — show a quick summary card prompt.
    return {
      type: "scheme-summary",
      heading: scheme.name,
      category: scheme.category,
      facts: Object.keys(scheme.facts).map((k) => scheme.facts[k].label),
      source: SOURCES.factsheet,
    };
  }

  return null; // fall through to LLM
}

const KB = {
  LAST_UPDATED,
  SOURCES,
  SCHEMES,
  GENERIC,
  isAdviceQuery,
  answerLocally,
  findScheme,
};

window.KB = KB;
