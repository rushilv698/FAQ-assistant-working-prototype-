// ===================== CHAT (FAQ ASSISTANT) SCREEN =====================

const CHIPS = [
  "Expense Ratio",
  "Exit Load",
  "Minimum SIP",
  "Riskometer",
  "Benchmark",
  "Lock-in Period",
  "Capital Gains Statement",
];

function timeNow() {
  return new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: true });
}

// LLM fallback for free-text questions not covered by the local corpus.
async function askLLM(question) {
  const sys =
    "You are a FACTS-ONLY mutual fund FAQ assistant for an Indian investing app. " +
    "Rules: (1) Only give factual, educational information about mutual fund CONCEPTS " +
    "(expense ratio, exit load, SIP, NAV, riskometer, ELSS, lock-in, benchmarks, taxation basics, statement processes). " +
    "(2) NEVER give investment advice, recommendations, predictions or opinions. " +
    "(3) If asked for specific live numbers (NAV, returns, AUM) you cannot verify, say you could not find it in approved sources. " +
    "(4) Keep answers under 70 words. " +
    "Respond ONLY with strict JSON: {\"type\":\"answer\"|\"refusal\"|\"error\", \"heading\":string, \"body\":string, \"org\":\"SEBI\"|\"AMFI\"|\"AMC\"}. " +
    "Use type 'refusal' for advice/opinion/prediction questions. Use 'error' if not a mutual fund question or no approved source covers it.";
  try {
    const raw = await window.claude.complete({
      messages: [
        { role: "user", content: sys + "\n\nQuestion: " + question },
      ],
    });
    const m = raw.match(/\{[\s\S]*\}/);
    const j = JSON.parse(m ? m[0] : raw);
    const orgMap = {
      SEBI: window.KB.SOURCES.sebi,
      AMFI: window.KB.SOURCES.amfi,
      AMC: window.KB.SOURCES.factsheet,
    };
    if (j.type === "refusal") {
      return { type: "refusal", body: j.body, source: window.KB.SOURCES.sebi };
    }
    if (j.type === "error") {
      return { type: "error" };
    }
    return {
      type: "answer",
      heading: j.heading || null,
      body: j.body,
      source: orgMap[j.org] || window.KB.SOURCES.sebi,
    };
  } catch (e) {
    return { type: "error" };
  }
}

function SourceCard({ source }) {
  return (
    <div className="source-card">
      <div className="source-line">
        <span className="source-key">Source:</span>
      </div>
      <a className="source-link" href={source.url} target="_blank" rel="noreferrer">
        <span>{source.label}</span>
        <I.External s={13} c="var(--blue)" />
      </a>
      <div className="source-meta">Last updated from sources: {window.KB.LAST_UPDATED}</div>
    </div>
  );
}

function UserMsg({ text, time }) {
  return (
    <div className="row user-row">
      <div className="bubble user-bubble">
        <div className="bubble-text">{text}</div>
        <div className="bubble-time">
          <span>{time}</span>
          <I.Check2 s={13} c="var(--green-dark)" />
        </div>
      </div>
      <div className="avatar user-avatar"><I.User s={17} c="var(--green-dark)" /></div>
    </div>
  );
}

function BotAvatar() {
  return (
    <div className="avatar bot-avatar">
      <img src="assets/groww-logo.png" alt="" width={26} height={26} />
    </div>
  );
}

function AnswerMsg({ msg }) {
  return (
    <div className="row bot-row">
      <BotAvatar />
      <div className="bubble bot-bubble">
        {msg.type === "answer" && (
          <React.Fragment>
            {msg.heading && <div className="ans-heading">{msg.heading}</div>}
            <div className="ans-body">{msg.body}</div>
            {msg.source && <SourceCard source={msg.source} />}
          </React.Fragment>
        )}

        {msg.type === "scheme-summary" && (
          <React.Fragment>
            <div className="ans-heading">{msg.heading}</div>
            <div className="scheme-cat">{msg.category}</div>
            <div className="ans-body">Here's what I have on record. Ask me about any of these:</div>
            <div className="summary-chips">
              {msg.facts.map((f, i) => (
                <span className="summary-chip" key={i}>{f}</span>
              ))}
            </div>
            {msg.source && <SourceCard source={msg.source} />}
          </React.Fragment>
        )}

        {msg.type === "refusal" && (
          <React.Fragment>
            <div className="refusal-tag">
              <I.NoAdvice s={14} c="var(--error)" />
              <span>Investment advice — not provided</span>
            </div>
            <div className="ans-body">{msg.body}</div>
            {msg.source && <SourceCard source={msg.source} />}
          </React.Fragment>
        )}

        {msg.type === "error" && (
          <React.Fragment>
            <div className="ans-body">
              I couldn't find this in the approved AMC, SEBI or AMFI sources. Try rephrasing, or ask
              about expense ratio, exit load, benchmark, riskometer, lock-in or minimum SIP for an
              SBI scheme.
            </div>
          </React.Fragment>
        )}
      </div>
    </div>
  );
}

function Typing() {
  return (
    <div className="row bot-row">
      <BotAvatar />
      <div className="bubble bot-bubble typing-bubble">
        <div className="dots"><span></span><span></span><span></span></div>
        <span className="typing-text">Searching official sources…</span>
      </div>
    </div>
  );
}

function EmptyState({ onPick }) {
  const examples = [
    "What is the expense ratio of SBI Bluechip Fund?",
    "What is the exit load of SBI Small Cap Fund?",
    "What is the lock-in period of SBI Long Term Equity Fund?",
    "What is the minimum SIP for SBI Magnum Midcap Fund?",
  ];
  return (
    <div className="empty-state">
      <div className="empty-logo">
        <img src="assets/groww-logo.png" alt="" width={48} height={48} />
      </div>
      <h2 className="empty-title">Ask anything about mutual funds</h2>
      <p className="empty-sub">
        Factual answers on expense ratios, exit loads, benchmarks, riskometers, lock-ins and SIPs —
        every one backed by an official source.
      </p>
      <div className="empty-examples">
        {examples.map((q, i) => (
          <button className="empty-ex" key={i} onClick={() => onPick(q)}>
            <span>{q}</span>
            <I.Arrow s={16} c="var(--green)" />
          </button>
        ))}
      </div>
    </div>
  );
}

function Chat({ seedQuestion, onNewChat, onHome, theme, onToggleTheme }) {
  const [messages, setMessages] = React.useState([]);
  const [input, setInput] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const scrollRef = React.useRef(null);
  const seededRef = React.useRef(false);

  const scrollToBottom = () => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  };

  React.useEffect(() => { scrollToBottom(); }, [messages, busy]);

  const submit = React.useCallback(async (text) => {
    const q = (text || "").trim();
    if (!q || busy) return;
    setInput("");
    setMessages((m) => [...m, { role: "user", text: q, time: timeNow() }]);
    setBusy(true);

    const local = window.KB.answerLocally(q);
    let result = local;
    // Simulate retrieval latency for realism.
    await new Promise((r) => setTimeout(r, local ? 750 : 100));
    if (!local) {
      result = await askLLM(q);
    }
    setBusy(false);
    setMessages((m) => [...m, { role: "bot", ...result }]);
  }, [busy]);

  // Seed an initial question coming from the landing page.
  React.useEffect(() => {
    if (seedQuestion && !seededRef.current) {
      seededRef.current = true;
      submit(seedQuestion);
    }
  }, [seedQuestion, submit]);

  const handleChip = (chip) => {
    setInput("What is the " + chip.toLowerCase() + " of SBI Small Cap Fund?");
  };

  return (
    <div className="screen chat">
      <header className="chat-header">
        <Logo size={30} textSize={21} onClick={onHome} />
        <div className="nav-right">
          <ThemeToggle theme={theme} onToggle={onToggleTheme} />
          <button className="btn-newchat" onClick={onNewChat}>
            <I.NewChat s={17} c="var(--green)" />
            <span>New Chat</span>
          </button>
        </div>
      </header>

      <div className="chat-banner">
        <FactsBadge />
        <div className="chips-row">
          {CHIPS.map((c, i) => (
            <button className="chip" key={i} onClick={() => handleChip(c)}>{c}</button>
          ))}
        </div>
      </div>

      <div className="chat-scroll" ref={scrollRef}>
        <div className="chat-inner">
          {messages.length === 0 && !busy && <EmptyState onPick={submit} />}
          {messages.map((m, i) =>
            m.role === "user" ? (
              <UserMsg key={i} text={m.text} time={m.time} />
            ) : (
              <AnswerMsg key={i} msg={m} />
            )
          )}
          {busy && <Typing />}
        </div>
      </div>

      <div className="chat-input-wrap">
        <div className="chat-input">
          <input
            type="text"
            placeholder="Ask a mutual fund question…"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && submit(input)}
            disabled={busy}
          />
          <button className="send-btn" disabled={!input.trim() || busy} onClick={() => submit(input)}>
            <I.Send s={19} c="#fff" />
          </button>
        </div>
        <div className="chat-foot-note">
          <I.Lock s={13} c="var(--faint)" />
          <span>We do not store or collect any personal or financial information.</span>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Chat });
